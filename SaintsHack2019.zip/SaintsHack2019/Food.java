
/**
 * This class keeps track of the amount of carbs, fat, and protein in grams.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Food
{
    private int carbs;
    private int fat;
    private int protein;
    private double carbPercent;
    private double fatPercent;
    private double proteinPercent;

    public Food()
    {
        carbs = 0;
        fat = 0;
        protein = 0;
    }

    public void setCarbs(int inputCarbs)
    {
        carbs = inputCarbs;
    }

    public void setFat(int inputFat)
    {
        fat = inputFat;
    }

    public void setProtein(int inputProtein)
    {
        protein = inputProtein;
    }

    public int getCarbs()
    {
        return carbs;
    }

    public int getFat()
    {
        return fat;
    }

    public int getProtein()
    {
        return protein;
    }

    public Goal carbs(int calories)
    {
        Goal goalCarbs;
        int calorieCarbs = carbs * 4;
        carbPercent = (calorieCarbs * 1.0) / calories;
        if(carbPercent >= 0.45 && carbPercent <= 0.65)
        {
            goalCarbs = Goal.MET;
        }
        else if(carbPercent < 0.45)
        {
            goalCarbs = Goal.ALMOST;
        }
        else
        {
            goalCarbs = Goal.OVER;
        }
        return goalCarbs;
    }

    public Goal fat(int calories)
    {
        Goal goalFat;
        int calorieFat = fat * 9;
        fatPercent = (calorieFat * 1.0) / calories;
        if(fatPercent >= 0.20 && fatPercent <= 0.35)
        {
            goalFat = Goal.MET;
        }
        else if(fatPercent < 0.20)
        {
            goalFat = Goal.ALMOST;
        }
        else
        {
            goalFat = Goal.OVER;
        }
        return goalFat;
    }

    public Goal protein(int calories)
    {
        Goal goalProtein;
        int calorieProtein = protein * 4;
        proteinPercent = (calorieProtein * 1.0) / calories;
        if(proteinPercent >= 0.15 && proteinPercent <= 0.25)
        {
            goalProtein = Goal.MET;
        }
        else if(proteinPercent < 0.15)
        {
            goalProtein = Goal.ALMOST;
        }
        else
        {
            goalProtein = Goal.OVER;
        }
        return goalProtein;
    }
   
    public String carbGoal(int calories)
    {
        String typeAndRange = "carbohydrates between 45 to 65 percent";
        Goal carbGoal = carbs(calories);

        return checkGoal(calories, typeAndRange, carbGoal);
    }

    public String fatGoal(int calories)
    {
        String typeAndRange = "fat between 20 to 35 percent";
        Goal fatGoal = fat(calories);

        return checkGoal(calories, typeAndRange, fatGoal);
    }

    public String proteinGoal(int calories)
    {
        String typeAndRange = "protein between 15 to 25 percent";
        Goal proteinGoal = protein(calories);

        return checkGoal(calories, typeAndRange, proteinGoal);
    }

    private String checkGoal(int calories, String typeAndRange, Goal foodGoal)
    {
        String reinforcement;

        if(foodGoal == Goal.MET)
        {
            reinforcement = "Nice work!\nYou reached your daily goal!";
        }
        else if(foodGoal == Goal.OVER)
        {
            reinforcement = "You went over your goal.\nYour goal is to ";
            reinforcement += "keep " + typeAndRange + " of your daily calories.";
        }
        else
        {
            reinforcement = "You are under your goal. Keep going to reach your goal!";
        }
        return reinforcement;
    }
}
