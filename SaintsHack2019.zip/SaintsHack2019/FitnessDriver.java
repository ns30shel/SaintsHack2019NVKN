import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import javax.swing.JFormattedTextField;

/**
 * This class will take input from the user and use the other classes to provide a diet and exercise program
 * catered to the user. 
 *
 * @author Nick && Van && Kate && Natasha
 * @version 0.0.1 (Spring 2019)
 */
public class FitnessDriver implements ActionListener
{
    private static int WIDTH = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
    private static int HEIGHT = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
    private static JFrame window = new JFrame("Fitness Helper");
    private static boolean running = false;
    private static String userName;
    private static int userAge;
    private static int userWeight;
    private static int userHeight;
    private static boolean weightUnits;
    private static boolean heightUnits;
    private static boolean userGender;
    private static int goalWeight;

    private static User currentUser;

    public static void main (String[] args) {
        window.setSize(WIDTH, HEIGHT); //Fullscreen Window
        window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        window.getContentPane().setBackground(Color.WHITE);

        JTextArea titleText = new JTextArea("Nutrition and Condition Tracker");
        titleText.setLocation(50, 50);
        titleText.setSize(WIDTH / 8, HEIGHT / 8);

        JButton createButton = new JButton("New User");
        createButton.setLocation((WIDTH / 6), (HEIGHT / 2));
        createButton.setSize(WIDTH / 6, HEIGHT / 6);
        createButton.setVisible(true);
        createButton.setBackground(Color.CYAN);
        createButton.setFont(new Font ("Arial", Font.BOLD, 36));

        JButton loadButton = new JButton("Load User");
        loadButton.setLocation(WIDTH - (WIDTH / 3), (HEIGHT / 2));
        loadButton.setSize(WIDTH / 6, HEIGHT / 6);
        loadButton.setVisible(true);
        loadButton.setBackground(Color.GREEN);
        loadButton.setFont(new Font ("Arial", Font.BOLD, 36));

        JButton uselessButton = new JButton("");
        uselessButton.setLocation((WIDTH / 10), (HEIGHT / 5));
        uselessButton.setSize(WIDTH / 8, HEIGHT / 6);
        uselessButton.setVisible(false);

        window.add(createButton);
        window.add(loadButton);
        window.add(uselessButton);

        window.setVisible(true);

        JFormattedTextField createTextBoxName = new JFormattedTextField();
        JFormattedTextField createTextBoxWeight = new JFormattedTextField();
        JFormattedTextField createTextBoxHeight = new JFormattedTextField();
        JFormattedTextField createTextBoxAge = new JFormattedTextField();
        JFormattedTextField createHeightUnit = new JFormattedTextField();
        JFormattedTextField createWeightUnit = new JFormattedTextField();
        JFormattedTextField createUserSex = new JFormattedTextField();
        JFormattedTextField createGoalWeight = new JFormattedTextField();

        JFormattedTextField loadTextBox = new JFormattedTextField();

        JFrame createFrame = smallFrameMaker("Create User", false);
        JFrame loadFrame = smallFrameMaker("Load User", false);

        createButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    createFrame.setVisible(true);

                    createTextBoxName.setColumns(15);
                    createTextBoxName.setSize(WIDTH / 10, HEIGHT / 30);
                    createTextBoxName.setLocation(WIDTH / 8, 0);
                    createTextBoxName.setText("Enter Name");
                    createTextBoxName.setVisible(true);
                    createFrame.add(createTextBoxName);

                    createTextBoxWeight.setColumns(15);
                    createTextBoxWeight.setSize(WIDTH / 10, HEIGHT / 30);
                    createTextBoxWeight.setLocation(WIDTH / 8, HEIGHT / 30);
                    createTextBoxWeight.setText("Enter Weight");
                    createTextBoxWeight.setVisible(true);
                    createFrame.add(createTextBoxWeight);

                    createTextBoxHeight.setColumns(15);
                    createTextBoxHeight.setSize(WIDTH / 10, HEIGHT / 30);
                    createTextBoxHeight.setLocation(WIDTH / 8, 2 * (HEIGHT / 30));
                    createTextBoxHeight.setText("Enter Height");
                    createTextBoxHeight.setVisible(true);
                    createFrame.add(createTextBoxHeight);

                    createTextBoxAge.setColumns(15);
                    createTextBoxAge.setSize(WIDTH / 10, HEIGHT / 30);
                    createTextBoxAge.setLocation(WIDTH / 8, 3 * (HEIGHT / 30));
                    createTextBoxAge.setText("Enter Age");
                    createTextBoxAge.setVisible(true);
                    createFrame.add(createTextBoxAge);

                    createWeightUnit.setColumns(15);
                    createWeightUnit.setSize(WIDTH / 10, HEIGHT / 30);
                    createWeightUnit.setLocation(WIDTH / 8, 4 * (HEIGHT / 30));
                    createWeightUnit.setText("Weight Units");
                    createWeightUnit.setVisible(true);
                    createFrame.add(createWeightUnit);

                    createHeightUnit.setColumns(15);
                    createHeightUnit.setSize(WIDTH / 10, HEIGHT / 30);
                    createHeightUnit.setLocation(WIDTH / 8, 5 * (HEIGHT / 30));
                    createHeightUnit.setText("Height Units");
                    createHeightUnit.setVisible(true);
                    createFrame.add(createHeightUnit);

                    createUserSex.setColumns(15);
                    createUserSex.setSize(WIDTH / 10, HEIGHT / 30);
                    createUserSex.setLocation(WIDTH / 8, 6 * (HEIGHT / 30));
                    createUserSex.setText("Enter Sex");
                    createUserSex.setVisible(true);
                    createFrame.add(createUserSex);

                    createGoalWeight.setColumns(15);
                    createGoalWeight.setSize(WIDTH / 10, HEIGHT / 30);
                    createGoalWeight.setLocation(WIDTH / 8, 7 * (HEIGHT / 30));
                    createGoalWeight.setText("Goal Weight");
                    createGoalWeight.setVisible(true);
                    createFrame.add(createGoalWeight);

                    JFormattedTextField fixer = new JFormattedTextField();
                    createFrame.add(fixer);
                    fixer.setVisible(false);

                    
                    //Operator.newUser();
                }
            });
            
            createGoalWeight.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    userName = createTextBoxName.getText();
                    userWeight = Integer.parseInt(createTextBoxWeight.getText());
                    userHeight = Integer.parseInt(createTextBoxHeight.getText());
                    userAge = Integer.parseInt(createTextBoxAge.getText());
                    weightUnits = Boolean.parseBoolean(createWeightUnit.getText());
                    heightUnits = Boolean.parseBoolean(createHeightUnit.getText());
                    userGender = Boolean.parseBoolean(createUserSex.getText());
                    goalWeight = Integer.parseInt(createGoalWeight.getText());
                    currentUser = new User(userName, userAge, userHeight, heightUnits, userWeight, goalWeight,
                    weightUnits, userGender);
                    loadButton.setVisible(false);
                    createButton.setVisible(false);
                    thirdWindow();
                    createFrame.dispose();
                }
            });

        loadButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    loadTextBox.setColumns(15);
                    loadTextBox.setSize(WIDTH / 20, HEIGHT / 30);
                    loadTextBox.setLocation(WIDTH / 8, HEIGHT / 8);
                    loadTextBox.setText("Enter Name");
                    loadFrame.setVisible(true);
                    loadFrame.add(loadTextBox);
                    JFormattedTextField fixerTextBox = new JFormattedTextField();
                    fixerTextBox.setVisible(false);
                    loadFrame.add(fixerTextBox);

                    //Load
                }
            });

        createTextBoxName.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    userName = createTextBoxName.getText();
                }
            });

        loadTextBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    userName = loadTextBox.getText();
                    thirdWindow();
                    loadButton.setVisible(false);
                    createButton.setVisible(false);
                    loadFrame.dispose();
                    currentUser = Operator.loadUser(userName);

                }
            });

        running = true;
        run();

    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }

    //This runs the actual code. 
    //Still need to write the comments.
    public static void thirdWindow () {

        JButton carbsInfoButton = buttonMaker (WIDTH / 50, HEIGHT / 30, (WIDTH / 5),
                (HEIGHT / 5) + (HEIGHT / 20), "?", Color.CYAN, 10);

        window.add(carbsInfoButton);

        carbsInfoButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    smallFrameMaker("Carbohydrates", true).setVisible(true);
                }
            });

        JTextArea carbsText = textMaker (WIDTH / 20, (HEIGHT / 5) + (HEIGHT / 20) + 5, "Carbohydrates: ",
                WIDTH / 10, HEIGHT / 5, WIDTH / 100);

        window.add(carbsText);

        JButton proteinInfoButton = buttonMaker (WIDTH / 50, HEIGHT / 30, (WIDTH / 5),
                (HEIGHT / 5) + (2 * (HEIGHT / 20)), "?", Color.CYAN, 10);

        window.add(proteinInfoButton);

        proteinInfoButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    smallFrameMaker("Proteins", true).setVisible(true);
                }
            });

        JTextArea proteinText = textMaker (WIDTH / 20, (HEIGHT / 5) + (2 * (HEIGHT / 20)) + 5, "Protein: ",
                WIDTH / 20, HEIGHT / 5, WIDTH / 100);

        window.add(proteinText);

        JButton fatInfoButton = buttonMaker (WIDTH / 50, HEIGHT / 30, (WIDTH / 5),
                (HEIGHT / 5) + (3 * (HEIGHT / 20)), "?", Color.CYAN, 10);

        window.add(fatInfoButton);

        fatInfoButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    smallFrameMaker("Good Fats and Bad Fats", true).setVisible(true);
                }
            });

        JTextArea fatText = textMaker (WIDTH / 20, (HEIGHT / 5) + (3 * (HEIGHT / 20)) + 5, "Fats: ",
                WIDTH / 20, HEIGHT / 5, WIDTH / 100);

        window.add(fatText);

        JButton sugarInfoButton = buttonMaker (WIDTH / 50, HEIGHT / 30, (WIDTH / 5),
                (HEIGHT / 5) + (4 * (HEIGHT / 20)), "?", Color.CYAN, 10);

        window.add(sugarInfoButton);

        sugarInfoButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    smallFrameMaker("Sugars", true).setVisible(true);
                }
            });

        JTextArea sugarText = textMaker (WIDTH / 20, (HEIGHT / 5) + (4 * (HEIGHT / 20)) + 5, "Sugars: ",
                WIDTH / 20, HEIGHT / 5, WIDTH / 100);

        window.add(sugarText);

        JButton fiberInfoButton = buttonMaker (WIDTH / 50, HEIGHT / 30, (WIDTH / 5),
                (HEIGHT / 5) + (5 * (HEIGHT / 20)), "?", Color.CYAN, 10);

        window.add(fiberInfoButton);

        fiberInfoButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    smallFrameMaker("Fiber", true).setVisible(true);
                }
            });

        JTextArea fiberText = textMaker (WIDTH / 20, (HEIGHT / 5) + (5 * (HEIGHT / 20)) + 5, "Fiber: ",
                WIDTH / 20, HEIGHT / 5, WIDTH / 100);

        window.add(fiberText);

        JButton sodiumInfoButton = buttonMaker (WIDTH / 50, HEIGHT / 30, (WIDTH / 5),
                (HEIGHT / 5) + (6 * (HEIGHT / 20)), "?", Color.CYAN, 10);

        window.add(sodiumInfoButton);

        sodiumInfoButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    smallFrameMaker("Sodium", true).setVisible(true);
                }
            });

        JTextArea sodiumText = textMaker (WIDTH / 20, (HEIGHT / 5) + (6 * (HEIGHT / 20)) + 5, "Sodium: ",
                WIDTH / 20, HEIGHT / 5, WIDTH / 100);
        JTextArea EnterText = textMaker (WIDTH / 4 + (WIDTH / 20), (HEIGHT / 5) + (3 * (HEIGHT / 20)) + 5,
                "<- Enter \n<- Here \n<- To \n<- Log", WIDTH / 20, HEIGHT / 5, WIDTH / 100);

        window.add(sodiumText);
        window.add(EnterText);

        JButton workoutInfoButton = buttonMaker (WIDTH / 5, HEIGHT / 6, (WIDTH / 5),
                (HEIGHT / 2) + (HEIGHT / 4), "WORKOUT PLAN", Color.YELLOW, WIDTH / 50);

        window.add(workoutInfoButton);

        workoutInfoButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    smallFrameMaker("Workouts", true).setVisible(true);
                }
            });

        JButton saveButton = buttonMaker (WIDTH / 5, HEIGHT / 6, 3 * (WIDTH / 5),
                (HEIGHT / 2) + (HEIGHT / 4), "SAVE/CLOSE", Color.YELLOW, WIDTH / 50);

        window.add(saveButton);

        saveButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Operator.saveUser(currentUser);
                    running = false;
                    window.dispose();
                }
            });

        JTextArea startingWeightText = textMaker (3 * (WIDTH / 5), 2 * (HEIGHT / 8), "Starting Weight",
                WIDTH / 6, HEIGHT / 8, WIDTH / 60);
        window.add(startingWeightText);

        JTextArea currentWeightText = textMaker (3 * (WIDTH / 5), 3 * (HEIGHT / 8), "Current Weight",
                WIDTH / 6, HEIGHT / 8, WIDTH / 60);
        window.add(currentWeightText);

        JTextArea goalWeightText = textMaker (3 * (WIDTH / 5), 4 * (HEIGHT / 8), "Goal Weight",
                WIDTH / 6, HEIGHT / 8, WIDTH / 60);
        window.add(goalWeightText);

        JTextArea unitsText = textMaker (WIDTH / 10, HEIGHT / 10 , "Recommended intake \nin Grams:",
                WIDTH / 6, HEIGHT / 8, WIDTH / 60);
        window.add(unitsText);

        JTextArea topText = textMaker (WIDTH / 3, HEIGHT / 20, "NUTRITION AND \tCONDITION TRACKER",
                WIDTH / 4, HEIGHT / 8, WIDTH / 50);
        window.add(topText);

        JTextArea userText = textMaker (WIDTH / 3, HEIGHT / 20 + 80, currentUser.getName(),
                WIDTH / 6, HEIGHT / 10, WIDTH / 60);
        window.add(userText);

        JFormattedTextField carbsBox = textBoxMaker((WIDTH / 30) + (WIDTH / 5), (HEIGHT / 5) + (HEIGHT / 20), "", 5);
        window.add(carbsBox);
        carbsBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //CHECK

                }
            });

        JFormattedTextField proteinBox = textBoxMaker((WIDTH / 30) + (WIDTH / 5), (HEIGHT / 5) + (2 * (HEIGHT / 20)), "", 5);
        window.add(proteinBox);
        proteinBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //CHECK

                }
            });

        JFormattedTextField fatBox = textBoxMaker((WIDTH / 30) + (WIDTH / 5), (HEIGHT / 5) + (3 * (HEIGHT / 20)), "", 5);
        window.add(fatBox);
        fatBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //CHECK

                }
            });

        JFormattedTextField sugarBox = textBoxMaker((WIDTH / 30) + (WIDTH / 5), (HEIGHT / 5) + (4 * (HEIGHT / 20)), "", 5);
        window.add(sugarBox);
        sugarBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //CHECK

                }
            });

        JFormattedTextField fiberBox = textBoxMaker((WIDTH / 30) + (WIDTH / 5), (HEIGHT / 5) + (5 * (HEIGHT / 20)), "", 5);
        window.add(fiberBox);
        fiberBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //CHECK

                }
            });

        JFormattedTextField sodiumBox = textBoxMaker((WIDTH / 30) + (WIDTH / 5), (HEIGHT / 5) + (6 * (HEIGHT / 20)), "", 5);
        window.add(sodiumBox);
        sodiumBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //CHECK

                }
            });

        JButton fixerButton = new JButton("");
        fixerButton.setLocation((WIDTH / 10), (HEIGHT / 5));
        fixerButton.setSize(WIDTH / 8, HEIGHT / 6);
        fixerButton.setVisible(false);
        window.add(fixerButton); 

    }

    //Makes Buttons
    //Finish writing comments later.
    public static JButton buttonMaker (int width, int height, int locationX, int locationY,
    String text, Color boxColor, int fontSize) {
        JButton newButton = new JButton(text);
        newButton.setLocation(locationX, locationY);
        newButton.setSize(width, height);
        newButton.setVisible(true);
        newButton.setBackground(boxColor);
        newButton.setFont(new Font ("Arial", Font.BOLD, fontSize));

        return newButton;
    }

    //Makes the smaller pop up frames.
    //Finish writing comments later.
    public static JFrame smallFrameMaker (String title, boolean button) {
        JFrame newFrame = new JFrame(title);
        newFrame.setSize(WIDTH / 3, HEIGHT / 3);

        if(button) {
            JButton okButton = buttonMaker (WIDTH / 20, HEIGHT / 20, (WIDTH / 8),
                    (HEIGHT / 5) , "OK", Color.WHITE, 20);
            newFrame.add(okButton);

            JButton fixerButton = buttonMaker (WIDTH / 20, HEIGHT / 20, (WIDTH / 8),
                    (HEIGHT / 5) + (6 * (HEIGHT / 20)), "OK", Color.GRAY, 20);
            fixerButton.setVisible(false);
            newFrame.add(fixerButton);

            okButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        newFrame.dispose();
                    }
                });

        }

        newFrame.setLocation(WIDTH / 3, HEIGHT / 3);
        newFrame.getContentPane().setBackground(Color.WHITE);
        return newFrame;
    }    

    //Makes the text areas.
    //Finish writing comments later.
    public static JTextArea textMaker (int locationX, int locationY, String input, int sizeX, int sizeY, int fontSize) {
        JTextArea textBox = new JTextArea(input);
        textBox.setLocation(locationX, locationY);
        textBox.setVisible(true);
        textBox.setWrapStyleWord(true);
        textBox.setLineWrap(true);
        textBox.setBackground(new Color (0, 0, 0, 0));
        textBox.setSize(sizeX, sizeY);
        textBox.setFont(new Font("Arial", Font.BOLD, fontSize));

        return textBox;
    }

    //Makes text boxes.
    //Finish writing comments later.
    public static JFormattedTextField textBoxMaker (int locationX, int locationY, String text, int length) {
        JFormattedTextField newTextBox = new JFormattedTextField(length);
        newTextBox.setText(text);
        newTextBox.setColumns(5);
        newTextBox.setLocation(locationX, locationY);
        newTextBox.setVisible(true);
        newTextBox.setSize(WIDTH / 30, HEIGHT / 30);

        return newTextBox;
    }

    //Repaints window constantly.
    //Finish writing comments later.
    public static void run() {
        while (running) {
            window.repaint();
        }
    }

}
