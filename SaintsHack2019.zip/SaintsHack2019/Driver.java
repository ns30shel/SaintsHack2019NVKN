import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * These classes create a new User file, load an old one, or save the current user information
 * to a file.
 *
 * @author Van, Nick, Kate, Natasha
 * @version 0.0.1
 */
public class Driver
{
    public static User newUser(String inputName, int inputAge, int height, boolean inputHeightUnit, double weight, double goalWeight, boolean inputWeightUnit, boolean inputSex)
    {
        User user = new User(inputName, inputAge, height, inputHeightUnit, weight, goalWeight, inputWeightUnit, inputSex);

        //Code to make the file writer
        PrintWriter pWriter = null;
        try 
        {
            File outFile = new File(user.getName() + ".txt");
            pWriter = new PrintWriter (new FileWriter (outFile));
        }
        catch (java.io.IOException jioe)
        {
            System.out.println("Cannot write to output file.");
        }

        pWriter.print(user.getName() + ",");
        pWriter.print(user.getAge() + ",");
        pWriter.print(height + ",");
        pWriter.print(inputHeightUnit + ",");
        pWriter.print(weight + ",");
        pWriter.print(goalWeight + ",");
        pWriter.print(inputWeightUnit + ",");
        pWriter.print(inputSex + ",");

        pWriter.close();
        return user;

    }

    public static User loadUser(String name)
    {
        Scanner sc = null;

        try
        {
            sc = new Scanner(new File(name + ".txt"));
        }
        catch(FileNotFoundException fne)
        {
            System.out.println("\nThe file " + name + ".txt cannot be found.");
            System.exit(1);
        }
        
        String dataLine = sc.nextLine();
        Scanner dataLineSC = new Scanner(dataLine);
        dataLineSC.useDelimiter(",");
        String nameInFile = dataLineSC.next();
        int age = Integer.parseInt(dataLineSC.next());
        int height = Integer.parseInt(dataLineSC.next());
        boolean heightUnit = dataLineSC.nextBoolean();
        double weight = Double.parseDouble(dataLineSC.next());
        double goalWeight = Double.parseDouble(dataLineSC.next());
        boolean weightUnit = dataLineSC.nextBoolean();
        boolean sex = dataLineSC.nextBoolean();
        
        User user = new User(nameInFile, age, height, heightUnit, weight, goalWeight, weightUnit, sex);
        
        System.out.println(nameInFile + " " + age + " " + weight + " " + goalWeight + " " + weightUnit + " " + height + " " + heightUnit + " " + sex);
        
        return user;
    }
    
    public static void saveUser(User user)
    {
        PrintWriter pWriter = null;
        try 
        {
            File outFile = new File(user.getName() + ".txt");
            pWriter = new PrintWriter (new FileWriter (outFile));
        }
        catch (java.io.IOException jioe)
        {
            System.out.println("Cannot write to output file.");
        }
        
        pWriter.print(user.getName() + ",");
        pWriter.print(user.getAge() + ",");
        if (user.isKILO())
        {
            pWriter.print(user.getWeightKILO() + ",");
            pWriter.print(user.getGoalWeightKILO() + ",");
            pWriter.print(user.isKILO());
        }
        else 
        {
            pWriter.print(user.getWeightLBS() + ",");
            pWriter.print(user.getGoalWeightLBS() + ",");
            pWriter.print(user.isKILO());
        }
        
        if(user.isINCH())
        {
            pWriter.print(user.getHeightINCH());
            pWriter.print(user.isINCH());
        }
        else
        {
            pWriter.print(user.getHeightCM());
            pWriter.print(user.isINCH());
        }
        
        pWriter.print(user.isMale());
        
        pWriter.close();
    }
}
