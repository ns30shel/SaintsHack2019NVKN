import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * These classes create a new User file, load an old one, or save the current user information
 * to a file.
 *
 * @author Van, Nick, Kate, Natasha
 * @version 0.0.1
 */
public class Operator
{
    /**
     * This method creates a User object which will store the permanent information about the user, including their
     * name, age, height, weight, weight goal, and sex. The choice of CM/In and Kg/Lbs is also chosen at this time, and
     * cannot be changed. All the information is saved in a .txt file named after the user, which can be read from other methods.
     * 
     * @param inputName A string - the user's name.
     * @param inputAge An integer - the user's age.
     * @param height An integer - the user's height in centimeters or inches.
     * @param inputHeightUnit A boolean - true for inches, false for centimeters.
     * @param weight A double - the user's weight in either pounds or kilograms.
     * @param goalWeight A double - the user's weight gain/loss goal.
     * @param inputWeightUnit A boolean - true for pounds, false for kilograms.
     * @param inputSex A boolean - true for male, false for female.
     * @return a User object.
     */
    public static User newUser(String inputName, int inputAge, int height, boolean inputHeightUnit, double weight, 
    double goalWeight, boolean inputWeightUnit, boolean inputSex)
    {
        User user = new User(inputName, inputAge, height, inputHeightUnit, weight, goalWeight, inputWeightUnit, inputSex);

        //Code to make the file writer
        PrintWriter pWriter = null;
        try 
        {
            File outFile = new File(user.getName() + ".txt");
            pWriter = new PrintWriter (new FileWriter (outFile));
        }
        catch (java.io.IOException jioe)
        {
            System.out.println("Cannot write to output file.");
        }

        pWriter.print(user.getName() + ",");
        pWriter.print(user.getAge() + ",");
        pWriter.print(height + ",");
        pWriter.print(inputHeightUnit + ",");
        pWriter.print(weight + ",");
        pWriter.print(goalWeight + ",");
        pWriter.print(inputWeightUnit + ",");
        pWriter.print(inputSex + ",");
        
        
        pWriter.print("STOP");
        
        pWriter.close();
        return user;
    }

    /**
     * This method reads information off of a .txt created at the same time as a user, named after the user. The information it reads is then used to create a new instance of the User 
     * object.
     * 
     * @param name A string - the user's name, used to find the .txt file.
     * @return A user object made from the information in the .txt file.
     */
    public static User loadUser(String name)
    {
        Scanner sc = null;

        try
        {
            sc = new Scanner(new File(name + ".txt"));
        }
        catch(FileNotFoundException fne)
        {
            System.out.println("\nThe file " + name + ".txt cannot be found.");
            System.exit(1);
        }

        String dataLine = sc.nextLine();
        Scanner dataLineSC = new Scanner(dataLine);
        dataLineSC.useDelimiter(",");
        String nameInFile = dataLineSC.next();
        int age = Integer.parseInt(dataLineSC.next());
        int height = Integer.parseInt(dataLineSC.next());
        boolean heightUnit = Boolean.parseBoolean(dataLineSC.next());
        double weight = Double.parseDouble(dataLineSC.next());
        double goalWeight = Double.parseDouble(dataLineSC.next());
        boolean weightUnit = Boolean.parseBoolean(dataLineSC.next());
        boolean sex = Boolean.parseBoolean(dataLineSC.next());
        ArrayList<Double> previousWeights = new ArrayList<Double>();

        String nextToAdd = dataLineSC.next();
        while(!nextToAdd.equals("STOP"))
        {
            previousWeights.add(Double.parseDouble(nextToAdd));
            nextToAdd = dataLineSC.next();
        }

        User user = new User(nameInFile, age, height, heightUnit, weight, goalWeight, weightUnit, sex);
        user.setPastWeight(previousWeights);

        return user;
    }

    /**
     * This method saves the information currently stored in the User instance to the text file. When the information is saved, the user's current weight will be stored in an array of 
     * previous weights, so that the user can track their weight changes over time.
     * 
     * @param user A User object, the one currently running in the program.
     */
    public static void saveUser(User user)
    {
        PrintWriter pWriter = null;
        try 
        {
            File outFile = new File(user.getName() + ".txt");
            pWriter = new PrintWriter (new FileWriter (outFile));
        }
        catch (java.io.IOException jioe)
        {
            System.out.println("Cannot write to output file.");
        }

        pWriter.print(user.getName() + ",");
        pWriter.print(user.getAge() + ",");
        
        if(user.isINCH())
        {
            pWriter.print(user.getHeightINCH() + ",");
            pWriter.print(user.isINCH() + ",");
        }
        else
        {
            pWriter.print(user.getHeightCM() + ",");
            pWriter.print(user.isINCH() + ",");
        }
        
        if (user.isKILO())
        {
            pWriter.print(user.getWeightKILO() + ",");
            pWriter.print(user.getGoalWeightKILO() + ",");
            pWriter.print(user.isKILO() + ",");
            user.getPastWeight().add(user.getWeightKILO());
        }
        else 
        {
            pWriter.print(user.getWeightLBS() + ",");
            pWriter.print(user.getGoalWeightLBS() + ",");
            pWriter.print(user.isKILO() + ",");
            user.getPastWeight().add(user.getWeightLBS());
        }

        

        pWriter.print(user.isMale() + ",");
        
        

        for (Double weight : user.getPastWeight())
        {
            pWriter.print(weight + ",");
        }
        
        pWriter.print("STOP");
        
        pWriter.close();
    }
}
