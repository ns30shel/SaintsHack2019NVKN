import java.util.Scanner;
/**
 * Write a description of class Test here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Test
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Name");
        String inputName = sc.nextLine();
        System.out.print("Age");
        int inputAge = sc.nextInt();
        System.out.print("Height");
        int height = sc.nextInt();
        System.out.print("Unit");
        String heightUnit = sc.next();
        boolean inputHeightUnit = false;
        if(heightUnit.equals("inches"))
        {
            inputHeightUnit = true;
        }
        System.out.print("Weight");
        double weight = sc.nextDouble();
        System.out.print("goalWeight");
        double goalWeight = sc.nextDouble();
        System.out.print("weightUnit");
        String weightUnit = sc.next();
        boolean inputWeightUnit = false;
        if(weightUnit.equals("pounds"))
        {
            inputWeightUnit = true;
        }
        System.out.print("Gender: true for male");
        boolean inputSex = sc.nextBoolean();
        System.out.println("ActivityLevel");
        ActivityLevel level = ActivityLevel.MODERATE;
        User user = new User(inputName, inputAge, height, inputHeightUnit, weight, goalWeight, inputWeightUnit, inputSex);
        user.setActivityLevel(level);
        int calories = user.calories();
        Food food = new Food();
        System.out.print("Carbs");
        food.setCarbs(sc.nextInt());
        System.out.print("Fat");
        food.setFat(sc.nextInt());
        System.out.print("Protein");
        food.setProtein(sc.nextInt());
         
        food.carbGoal(calories);
        food.fat(calories);
        food.protein(calories);
        
        Exercise exercise = new Exercise();
        System.out.print("Hours");
        double inputHours = sc.nextDouble();
        exercise.setExercise(inputHours);
        Goal goalMet = exercise.exerciseGoal(level);
        System.out.println(exercise.toString(goalMet) + "\n");
        System.out.println(food.carbGoal(calories) + "\n");
        System.out.println(food.fatGoal(calories) + "\n");
        System.out.println(food.proteinGoal(calories) + "\n");
    }
}
