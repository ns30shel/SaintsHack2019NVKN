import java.util.ArrayList;
/**
 * Write a description of class Exercise here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Exercise
{
    private double hours;
    ArrayList<Double> recordedHours;

    public Exercise()
    {
        hours = 0;
        recordedHours = new ArrayList<Double>();

    }

    public void setExercise(double inputHours)
    {
        recordedHours.add(hours);
        hours = inputHours;
    }

    public double getExercise()
    {
        return hours;
    }

    public Goal exerciseGoal(ActivityLevel level)
    {
        Goal goalMet = Goal.MET;
        double goalHours = 0.0;
        if(level == ActivityLevel.NONE)
        {
            goalHours = 0.0;
        }
        else if(level == ActivityLevel.LIGHT)
        {
            goalHours = 0.5;
        }
        else if(level == ActivityLevel.MODERATE)
        {
            goalHours = 1.0;
        }
        else if(level == ActivityLevel.VERY)
        {
            goalHours = 1.5;
        }
        else if(level == ActivityLevel.EXTREMELY)
        {
            goalHours = 2;
        }

        if(hours < goalHours - 0.25)
        {
            goalMet = Goal.ALMOST;
        }
        else if(hours > goalHours + 0.25)
        {
            goalMet = Goal.OVER;
        }
        return goalMet;
    }

    public String toString(Goal goalMet)
    {
        String goalString;
        
        if(goalMet == goalMet.MET)
        {
            goalString = "Your goal has been met";
        }
        else if(goalMet == goalMet.OVER)
        {
            goalString = "Congratulations you exceeded your goal.";
        }
        else
        {
            goalString = "You have not made your goal for today.";
        }

        return "You have exercised " + hours + " today.\n" + goalString;
    }
}
